
//How to convert char to int




class chartoint
{

        public static void main(String a[])
        {


             
                 char myChar = 'A'; 
                 int myInt = myChar;

           System.out.println("Character value: "+ myChar);
           System.out.println();
           System.out.println("Value after convert to Int: "+ myInt);




        }





}