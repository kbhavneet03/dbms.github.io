
// How to convert String to int
public class StrToInt 
{
	public static void main(String[] args) 
	{
		String str = "123";
		int i=Integer.parseInt(str);
		System.out.println("String is : "+str);
		System.out.println("Str Convert to a int: "+ i);
		System.out.println(1+i);
		
	}

}
