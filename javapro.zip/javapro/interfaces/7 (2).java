interface Sortable {
    void sort(int[] arr);
}