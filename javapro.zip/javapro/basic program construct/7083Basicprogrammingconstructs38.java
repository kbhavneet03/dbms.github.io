class cuboid_Sarea   
{    
public static void main (String args[])   
 {   float  l, w, h, s_area;       
     l = 10;  
     w =20;  
     h = 30;  
    s_area  = 2*( l *w  + w* h + h*l);  
     System.out.println ("Surface Area of Cuboid is: "); 
       System.out.println(s_area);   
   
}}  