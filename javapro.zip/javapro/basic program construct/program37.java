/*
-   programmer:MayankDevil
-   37. Java Program to find volume of cone
*/ 
class Test
{
    public static void main(String args[])
    {
        double r = 3;

        double h = 5;

        System.out.println("Volume Of Cone is: "+((22 * r * r * h) / (3 * 7)));
    }
}
// the end