public class basicprogram7048_120 {

    public static void main(String[] args) {
        System.out.println(averageOfThree(5, 10, 15)); // 10.0
    }

    public static double averageOfThree(int num1, int num2, int num3) {
        return (num1 + num2 + num3) / 3.0;
    }
}