 class cylinder_Sarea
{  
 public static void main(String args[])  
{  
 float r, h, s_area;  
  r = 10;  
  h  = 20;  
  s_area = (22*r*(r+h))/7;  
  System.out.println("Surface Area of Cylinder is: "+s_area);  
}  
}  