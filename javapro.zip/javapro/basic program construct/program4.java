/*
-   programmer:MayankDevil
-   4. Write a Java program to print the sum, multiply, subtract, divide and remainder of two numbers
*/ 
class Test
{
    public static void main(String args[])
    {
        int n1 = 5;

        int n2 = 3;

        System.out.println("The two number"+n1+" and "+n2
            +"\n sum is "+(n2+n1)
            +"\n multiply is "+(n2*n1)
            +"\n subtract is "+(n2-n1)
            +"\n divide is "+(n2/n1)
            +"\n remainder is "+(n2%n1)
            );
        
    }
}
// the end