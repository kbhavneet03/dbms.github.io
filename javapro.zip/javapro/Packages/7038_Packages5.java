package PK1;
class Class1 {
    public void printMessage() {
        System.out.println("This is the first class in the first package.");
    }
    public static void main(String[] args) {
        new Class1().printMessage();
    }
}



class Class2 {
    public void printMessage() {
        System.out.println("This is the second class in the second package.");
    }
    public static void main(String[] args) {
        new Class2().printMessage();
        }
}



class Class3 {
    public void printMessage() {
        System.out.println("This is the third class in the third package.");
    }
    public static void main(String[] args) {
        new Class3().printMessage();
        }
}